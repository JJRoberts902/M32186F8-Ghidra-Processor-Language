// EvoPro / Mitsubishi M32R helper script for Ghidra 11.x
// Run after importing a 1MB Mitsubishi M32R ROM with language: m32r:2:mitsubishi-fp8000 or m32r:2:fp8000.
// Purpose: create corrected RAM/SFR blocks, label key Mitsubishi ROM ID locations,
// parse Renesas interrupt vector pointer entries, create functions at handler targets,
// and lightly scan for function-pointer tables.

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.data.DWordDataType;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.BookmarkType;
import ghidra.program.model.symbol.RefType;
import ghidra.program.model.symbol.ReferenceManager;
import ghidra.program.model.symbol.SourceType;

public class M32R_Mitsubishi_AutoSetup extends GhidraScript {

    private static final long FLASH_START = 0x00000000L;
    private static final long FLASH_END   = 0x000FFFFFL;
    private static final long SFR_START   = 0x00800000L;
    private static final long SFR_SIZE    = 0x00004000L;
    private static final long RAM_START   = 0x00804000L;
    private static final long RAM_SIZE    = 0x00010000L;

    private static final boolean SCAN_POINTER_TABLES = true;
    private static final int MIN_POINTER_RUN = 3;

    private final String[][] VECTOR_PTRS = new String[][] {
        {"TIN3_6", "0x94"}, {"TIN20_29", "0x98"}, {"TIN12_19", "0x9C"}, {"TIN0_2", "0xA0"},
        {"TIN7_11", "0xA4"}, {"TMS0_1", "0xA8"}, {"TOP8_9", "0xAC"}, {"TOP10", "0xB0"},
        {"TIO4_7", "0xB4"}, {"TIO8_9", "0xB8"}, {"TOP0_5", "0xBC"}, {"TOP6_7", "0xC0"},
        {"TIO0_3", "0xC4"}, {"DMA0_4", "0xC8"}, {"SIO1R", "0xCC"}, {"SIO1T", "0xD0"},
        {"SIO0R", "0xD4"}, {"SIO0T", "0xD8"}, {"AD0", "0xDC"}, {"TID0", "0xE0"},
        {"TOU0", "0xE4"}, {"DMA5_9", "0xE8"}, {"SIO2_3", "0xEC"}, {"RTD", "0xF0"},
        {"TID1", "0xF4"}, {"TOU1_2", "0xF8"}, {"SIO4_5", "0xFC"}, {"AD1", "0x100"},
        {"TID2", "0x104"}, {"TIN30_33", "0x108"}, {"CAN0", "0x10C"}, {"CAN1", "0x110"}
    };

    @Override
    public void run() throws Exception {
        if (currentProgram == null) {
            printerr("Open a program first.");
            return;
        }

        println("=== EvoPro M32R Mitsubishi Auto Setup ===");
        println("Program: " + currentProgram.getName());
        println("Language: " + currentProgram.getLanguageID());

        ensureBlock("SFR", SFR_START, SFR_SIZE, false, "Renesas M32R/ECU SFR area, 16KB");
        ensureBlock("RAM", RAM_START, RAM_SIZE, false, "Renesas M32R/ECU internal RAM, 64KB for F8 profile");

        labelAddress(0x00000000L, "M32R_Reset_RI_Vector");
        labelAddress(0x00000080L, "M32R_EI_Vector");
        labelAddress(0x00000090L, "M32R_FPE_Vector");

        labelAddress(0x00800000L, "IVECT");
        labelAddress(0x00800004L, "IMASK");
        labelAddress(0x00800060L, "ICAN0CR");
        labelAddress(0x0080007FL, "ICAN1CR");
        labelAddress(0x00801000L, "CAN0_SFR_BASE");
        labelAddress(0x00801400L, "CAN1_SFR_BASE");
        labelAddress(0x00801000L, "CAN0CNT");
        labelAddress(0x00801400L, "CAN1CNT");
        labelAddress(0x00804000L, "RAM_BASE_00804000");
        labelAddress(0x00813FFFL, "RAM_END_00813FFF");

        bookmarkRomId(0x00040020L, "Possible fallback Mitsubishi ROM ID area");
        bookmarkRomId(0x00050020L, "Common Mitsubishi ROM ID area used by many Evo/Ralliart/Lancer ROMs");
        bookmarkRomId(0x0005002AL, "Common ECUFlash internalidaddress-style ROM ID location");

        createEntryFunction(0x00000000L, "M32R_Reset_RI_Entry");
        createEntryFunction(0x00000080L, "M32R_ExternalInterrupt_Entry");
        createEntryFunction(0x00000090L, "M32R_FloatingPointException_Entry");

        bookmarkFlashBlocks();
        parseVectorPointers();

        if (SCAN_POINTER_TABLES) {
            scanFunctionPointerTables();
        }

        println("Done. Re-run normal analysis after this script if needed.");
    }

    private Address addr(long offset) {
        return toAddr(offset);
    }

    private void ensureBlock(String name, long start, long size, boolean initialized, String comment) throws Exception {
        Memory mem = currentProgram.getMemory();
        Address a = addr(start);
        MemoryBlock existing = mem.getBlock(a);
        if (existing != null) {
            println("Memory block exists at " + a + ": " + existing.getName() + " size=0x" + Long.toHexString(existing.getSize()));
            if (existing.getName().equals(name) && existing.getSize() != size) {
                println("  NOTE: expected " + name + " size 0x" + Long.toHexString(size) + "; current block differs. Not resizing automatically.");
            }
            return;
        }
        MemoryBlock block = mem.createUninitializedBlock(name, a, size, false);
        block.setRead(true);
        block.setWrite(true);
        block.setExecute(false);
        block.setVolatile(name.equals("SFR"));
        block.setComment(comment);
        println("Created block " + name + " @ " + a + " size 0x" + Long.toHexString(size));
    }

    private void labelAddress(long offset, String name) {
        try {
            createLabel(addr(offset), name, false, SourceType.USER_DEFINED);
        }
        catch (Exception e) {
            println("Label skipped " + name + " @ 0x" + Long.toHexString(offset) + ": " + e.getMessage());
        }
    }

    private void bookmarkRomId(long offset, String note) {
        try {
            Address a = addr(offset);
            labelAddress(offset, "MITSU_ROM_ID_CANDIDATE_" + Long.toHexString(offset).toUpperCase());
            createBookmark(a, BookmarkType.ANALYSIS, "EvoPro", note);
            println("Bookmarked ROM ID candidate @ " + a + " - " + note);
        }
        catch (Exception e) {
            println("ROM ID bookmark skipped @ 0x" + Long.toHexString(offset) + ": " + e.getMessage());
        }
    }

    private void createEntryFunction(long offset, String name) {
        tryCreateFunction(addr(offset), name);
    }

    private void bookmarkFlashBlocks() {
        long[] boundaries = new long[] {
            0x00000000L, 0x00002000L, 0x00003000L, 0x00004000L, 0x00008000L,
            0x00010000L, 0x00020000L, 0x00030000L, 0x00040000L, 0x00050000L,
            0x00060000L, 0x00070000L, 0x00080000L, 0x00090000L, 0x000A0000L,
            0x000B0000L, 0x000C0000L, 0x000D0000L, 0x000E0000L, 0x000F0000L,
            0x00100000L
        };
        for (int i = 0; i < boundaries.length - 1; i++) {
            long start = boundaries[i];
            long end = boundaries[i + 1] - 1;
            labelAddress(start, String.format("FLASH_BLOCK_%02d_%06X_%06X", i, start, end));
        }
        labelAddress(0x000FFFFFL, "FLASH_END_000FFFFF");
    }

    private void parseVectorPointers() throws Exception {
        println("Parsing M32R/ECU interrupt vector pointer entries...");
        Memory mem = currentProgram.getMemory();
        ReferenceManager refs = currentProgram.getReferenceManager();
        Listing listing = currentProgram.getListing();

        for (String[] entry : VECTOR_PTRS) {
            String vecName = entry[0];
            long vectorOffset = Long.decode(entry[1]);
            Address vectorAddr = addr(vectorOffset);

            labelAddress(vectorOffset, "VEC_PTR_" + vecName);
            try {
                if (listing.getDataAt(vectorAddr) == null) {
                    createData(vectorAddr, DWordDataType.dataType);
                }
            }
            catch (Exception ignored) { }

            long raw = mem.getInt(vectorAddr) & 0xffffffffL;
            long targetOffset = raw & 0xfffffffcL;
            if (!isFlashAddress(targetOffset) || targetOffset == 0 || targetOffset == 0xffffffffL) {
                println("  " + vecName + " vector @ " + vectorAddr + " raw=0x" + Long.toHexString(raw) + " not a valid internal flash target");
                continue;
            }

            Address target = addr(targetOffset);
            refs.addMemoryReference(vectorAddr, target, RefType.DATA, SourceType.ANALYSIS, 0);
            createBookmark(vectorAddr, BookmarkType.ANALYSIS, "M32R Vector", vecName + " -> " + target);
            tryCreateFunction(target, "ISR_" + vecName);
            println("  " + vecName + " -> " + target);
        }
    }

    private void scanFunctionPointerTables() throws Exception {
        println("Scanning for likely 32-bit function-pointer tables inside internal flash...");
        Memory mem = currentProgram.getMemory();
        ReferenceManager refs = currentProgram.getReferenceManager();
        Listing listing = currentProgram.getListing();
        int tables = 0;
        int funcs = 0;

        monitor.initialize((FLASH_END - FLASH_START + 1) / 4);
        long runStart = -1;
        java.util.ArrayList<Long> runValues = new java.util.ArrayList<>();

        for (long off = FLASH_START; off <= FLASH_END - 4; off += 4) {
            monitor.checkCancelled();
            monitor.incrementProgress(1);

            long raw;
            try {
                raw = mem.getInt(addr(off)) & 0xffffffffL;
            }
            catch (Exception e) {
                flushPointerRun(runStart, runValues, refs, listing);
                runStart = -1;
                runValues.clear();
                continue;
            }

            long target = raw & 0xfffffffcL;
            boolean valid = isFlashAddress(target) && target != 0 && target != off && raw != 0xffffffffL;
            if (valid) {
                if (runStart < 0) runStart = off;
                runValues.add(raw);
            }
            else {
                int made = flushPointerRun(runStart, runValues, refs, listing);
                if (made > 0) {
                    tables++;
                    funcs += made;
                }
                runStart = -1;
                runValues.clear();
            }
        }
        int made = flushPointerRun(runStart, runValues, refs, listing);
        if (made > 0) {
            tables++;
            funcs += made;
        }
        println("Pointer table scan complete. Candidate tables=" + tables + ", functions/references touched=" + funcs);
    }

    private int flushPointerRun(long runStart, java.util.ArrayList<Long> values, ReferenceManager refs, Listing listing) {
        if (runStart < 0 || values.size() < MIN_POINTER_RUN) return 0;
        int made = 0;
        try {
            Address tableAddr = addr(runStart);
            createBookmark(tableAddr, BookmarkType.ANALYSIS, "Possible function pointer table", "Run of " + values.size() + " internal flash pointers");
            labelAddress(runStart, "PTR_TABLE_" + Long.toHexString(runStart).toUpperCase());
            for (int i = 0; i < values.size(); i++) {
                long slotOff = runStart + i * 4L;
                long targetOff = values.get(i) & 0xfffffffcL;
                Address slot = addr(slotOff);
                Address target = addr(targetOff);
                try {
                    if (listing.getDataAt(slot) == null) {
                        createData(slot, DWordDataType.dataType);
                    }
                }
                catch (Exception ignored) { }
                refs.addMemoryReference(slot, target, RefType.DATA, SourceType.ANALYSIS, 0);
                tryCreateFunction(target, "PTRSUB_" + Long.toHexString(targetOff).toUpperCase());
                made++;
            }
        }
        catch (Exception e) {
            println("Pointer run skipped @ 0x" + Long.toHexString(runStart) + ": " + e.getMessage());
        }
        return made;
    }

    private boolean isFlashAddress(long v) {
        return v >= FLASH_START && v <= FLASH_END && (v & 1) == 0;
    }

    private void tryCreateFunction(Address entry, String preferredName) {
        try {
            if (!isFlashAddress(entry.getOffset())) return;
            if (getFunctionAt(entry) == null) {
                disassemble(entry);
                createFunction(entry, preferredName);
            }
            else if (getFunctionAt(entry) != null && getFunctionAt(entry).getName().startsWith("FUN_")) {
                getFunctionAt(entry).setName(preferredName, SourceType.ANALYSIS);
            }
        }
        catch (Exception e) {
            println("Function create skipped " + preferredName + " @ " + entry + ": " + e.getMessage());
        }
    }
}

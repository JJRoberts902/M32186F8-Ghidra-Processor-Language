No compiled Java plugin is required for this repack. The useful automation is supplied as a Ghidra script under ghidra_scripts/.
